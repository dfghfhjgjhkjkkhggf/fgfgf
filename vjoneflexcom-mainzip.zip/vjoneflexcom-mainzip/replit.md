# VJ ONEFLEX

A serverless movie/series/animation streaming platform powered entirely by Firebase — no backend server.

## Run & Operate

- `pnpm install --frozen-lockfile` — install the imported workspace dependencies.
- Use the Run button / managed `artifacts/omnisave: web` workflow. It runs `pnpm --filter @workspace/omnisave run dev`; the artifact supplies `PORT=23671` and `BASE_PATH=/`, and Replit routes it into the preview.
- `PORT=5000 BASE_PATH=/ pnpm --filter @workspace/omnisave run dev` — standalone alternative; do not run alongside the managed workflow.
- `pnpm --filter @workspace/omnisave run build` — build the frontend into `artifacts/omnisave/dist/public` (verified successfully).
- `pnpm run typecheck` — currently fails because the imported root configuration references missing `lib/` packages. The app-level typecheck also includes leftover React files and reports Vue errors; startup and the Vite build work independently.

### Setup verification and limits

- The Replit preview and `/movies` return HTTP 200; the homepage renders catalog content from the existing Firebase project.
- Signed-in/admin screens and payment transactions were not verified.
- Payments require server-side `PESAPAL_CONSUMER_KEY` and `PESAPAL_CONSUMER_SECRET` secrets. These were not supplied during import; do not invent credentials.
- The existing Vite development plugin serves `/api/pesapal` using `api/pesapal-proxy.js`. The configured static production artifact does not execute that handler; published checkout requires a separately supported serverless/API setup.
- The artifact's imported OmniSave label is stale; the rendered app is VJ ONEFLEX.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: Vue 3 + Vue Router + Vite
- Styling: Tailwind CSS v4
- Backend: **Firebase only** (Auth + Firestore + Storage)
- **No Express server. No PostgreSQL. Fully serverless.**

## Where things live

- `artifacts/omnisave/` — the Vue 3 frontend (the entire app)
- `artifacts/omnisave/src/lib/firebase.ts` — Firebase initialization (project: vj-oneflex-1b735)
- `artifacts/omnisave/src/store/db.ts` — all Firestore listeners & CRUD
- `artifacts/omnisave/src/store/auth.ts` — Firebase Auth (email/password + Google)
- `artifacts/omnisave/src/views/` — page views (Home, Movies, Series, Animation, Admin)
- `artifacts/omnisave/src/views/admin/` — admin dashboard tabs

## Firestore collections

- `movies` — movie catalog
- `series` — TV series with nested episodes array
- `animation` — animation content
- `carousel` — homepage hero carousel slides
- `users/{uid}` — user profiles (name, email, joinedAt, lastLogin)
- `subscriptions/{uid}` — active user subscription plans
- `paymentLogs` — payment transaction history

## Architecture decisions

- **Firestore only** — no Realtime Database, no PostgreSQL, no backend API
- **Serverless** — the Vue app runs in the browser and talks directly to Firebase
- **Firebase config hardcoded** in `firebase.ts` (client-side keys, safe by design)
- `db.ts` uses `onSnapshot` for real-time listeners; exports reactive Vue `ref`s consumed by all views
- Transactions tab merges `paymentLogs` + `subscriptions` collections to show all payment activity
- Status normalization: Firebase may store `completed`/`success`/`successful` — all normalized to `Successful`
- `optimizeDeps.include` in vite.config.ts pre-bundles Firebase packages to avoid Vite HMR reload error on first load

## Admin access

- Admin check: `currentUser.email === 'okotstephen57@gmail.com'`
- Route: `/admin`

## User preferences

- Firebase config must remain hardcoded (not env vars) — Vite does not expose env vars correctly at runtime in this setup
- No backend server — keep everything serverless/Firebase-only
- Firestore is the only database — do not add Realtime Database imports
