import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
import type { Plugin, ViteDevServer } from "vite";
import type { IncomingMessage, ServerResponse } from "node:http";
// @ts-ignore The same JS handler is used by Vercel's serverless-function runtime.
import pesapalProxy from "./api/pesapal-proxy.js";

const port = Number(process.env.PORT ?? "5000");
const basePath = process.env.BASE_PATH ?? "/";

type DevPesapalRequest = IncomingMessage & {
  query: Record<string, string>;
  body?: unknown;
};

type DevPesapalResponse = ServerResponse & {
  status: (statusCode: number) => DevPesapalResponse;
  send: (value: unknown) => DevPesapalResponse;
  json: (value: unknown) => DevPesapalResponse;
};

function pesapalDevApiPlugin(): Plugin {
  return {
    name: "pesapal-dev-api",
    configureServer(server: ViteDevServer) {
      server.middlewares.use("/api/pesapal", async (request, response) => {
        const req = request as DevPesapalRequest;
        const res = response as DevPesapalResponse;
        const requestUrl = new URL(req.url ?? "/", "http://localhost");
        req.query = {
          path: requestUrl.pathname.replace(/^\/+/, ""),
          ...Object.fromEntries(requestUrl.searchParams.entries()),
        };

        if (req.method !== "GET" && req.method !== "HEAD" && req.method !== "OPTIONS") {
          const chunks = [];
          for await (const chunk of req) chunks.push(chunk);
          const rawBody = Buffer.concat(chunks).toString("utf8");
          if (rawBody) {
            try {
              req.body = JSON.parse(rawBody);
            } catch {
              req.body = rawBody;
            }
          }
        }

        res.status = (statusCode: number) => {
          res.statusCode = statusCode;
          return res;
        };
        res.send = (value: unknown) => {
          if (typeof value === "object" && value !== null) {
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(value));
          } else {
            res.end(typeof value === "string" ? value : JSON.stringify(value));
          }
          return res;
        };
        res.json = (value: unknown) => {
          res.setHeader("Content-Type", "application/json");
          res.end(JSON.stringify(value));
          return res;
        };

        await pesapalProxy(req, res);
      });
    },
  };
}

export default defineConfig({
  base: basePath,
  plugins: [
    vue(),
    tailwindcss(),
    pesapalDevApiPlugin(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, ".."),
            }),
          ),
          await import("@replit/vite-plugin-dev-banner").then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
    },
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  optimizeDeps: {
    include: [
      'firebase/app',
      'firebase/auth',
      'firebase/firestore',
      'firebase/storage',
    ],
  },
  server: {
    port,
    strictPort: true,
    host: "0.0.0.0",
    allowedHosts: true,
    hmr: false,
    fs: {
      strict: false,
    },
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});
