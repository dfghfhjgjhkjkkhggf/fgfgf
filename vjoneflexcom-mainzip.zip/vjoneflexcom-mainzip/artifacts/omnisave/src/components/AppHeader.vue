<template>
  <header class="sticky top-0 z-50">
    <div class="header-bar">
      <div class="header-inner">

        <!-- Brand -->
        <RouterLink to="/" class="brand-link">
          <img src="/logo.png" alt="VJ ONEFLEX" class="brand-logo" />
          <div class="brand-text">
            <span class="brand-name">VJ ONEFLEX</span><span class="brand-dot">.COM</span>
          </div>
        </RouterLink>

        <!-- Desktop nav -->
        <nav class="hidden items-center gap-0.5 lg:flex">
          <RouterLink v-for="item in navItems" :key="item.path" :to="item.path" class="nav-item" :class="{ 'nav-item--active': $route.path === item.path, 'nav-item--admin': item.label === 'ADMIN' }">{{ item.label }}</RouterLink>
        </nav>

        <!-- Search bar — visible on desktop always, on mobile shown inline -->
        <form class="header-search" @submit.prevent="doSearch">
          <svg class="hs-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
          </svg>
          <input v-model="searchQuery" type="text" placeholder="Search movies, series, anime..." class="hs-input" @keyup.enter="doSearch" />
          <button type="submit" class="hs-btn">GO</button>
        </form>

        <!-- Right actions -->
        <div class="right-actions">

          <!-- Install App -->
          <button v-if="isInstallable" class="btn-install" @click="promptInstall" title="Install App">
            <svg class="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
            </svg>
            <span class="install-label">INSTALL</span>
          </button>

          <!-- Subscribe -->
          <!-- Theme toggle -->
          <button class="btn-theme" @click="toggleTheme" :title="theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'">
            <svg v-if="theme === 'dark'" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
            </svg>
            <svg v-else width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
          </button>

          <button class="btn-subscribe" @click="handleSubscribeClick">
            <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M2 19h20v2H2v-2zm2-3l3-8 5 4 4-6 3 10H4z"/></svg>
            <span class="sub-label">SUBSCRIBE</span>
          </button>

          <div class="h-4 w-px bg-white/15"></div>

          <!-- Logged in -->
          <div v-if="isLoggedIn" class="user-menu">
            <div class="user-avatar-wrap">
              <div class="user-avatar">{{ userInitial }}</div>
              <span class="hidden sm:inline user-name-short">{{ userName }}</span>
            </div>
            <button class="btn-logout" @click="handleLogout" title="Sign out">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>
              <span class="logout-label">LOGOUT</span>
            </button>
          </div>

          <!-- Logged out -->
          <button v-else class="btn-login" @click="loginOpen = true">
            <svg class="h-3.5 w-3.5 opacity-60" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
            <span class="login-label">LOGIN</span>
          </button>

        </div>
      </div>
    </div>
  </header>

  <!-- Bottom mobile navigation bar -->
  <nav class="mobile-bottom-nav">
    <RouterLink
      v-for="item in navItems"
      :key="item.path"
      :to="item.path"
      class="mob-nav-item"
      :class="{ 'mob-nav-item--active': $route.path === item.path, 'mob-nav-item--admin': item.label === 'ADMIN' }"
    >
      <!-- Home icon -->
      <svg v-if="item.label === 'HOME'" class="mob-nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
        <path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
      </svg>
      <!-- Movies icon -->
      <svg v-else-if="item.label === 'MOVIES'" class="mob-nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
        <path stroke-linecap="round" stroke-linejoin="round" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"/>
      </svg>
      <!-- Series icon -->
      <svg v-else-if="item.label === 'SERIES'" class="mob-nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
        <path stroke-linecap="round" stroke-linejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
      </svg>
      <!-- Animation icon -->
      <svg v-else-if="item.label === 'ANIMATION'" class="mob-nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
        <path stroke-linecap="round" stroke-linejoin="round" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/>
        <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
      </svg>
      <!-- Admin icon -->
      <svg v-else-if="item.label === 'ADMIN'" class="mob-nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
        <path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
      </svg>
      <span class="mob-nav-label">{{ item.label === 'ANIMATION' ? 'ANIME' : item.label }}</span>
    </RouterLink>
  </nav>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import { useAuth } from '../store/auth'
import { loginOpen, subscribeOpen } from '../store/ui'
import { usePWAInstall } from '../composables/usePWAInstall'
import { theme, toggleTheme } from '../store/theme'

const router = useRouter()
const menuOpen = ref(false)
const searchQuery = ref('')

const { currentUser, isLoggedIn, isAdmin, logOut } = useAuth()
const { isInstallable, promptInstall } = usePWAInstall()

const userInitial = computed(() => {
  const name = currentUser.value?.displayName || currentUser.value?.email || '?'
  return name[0].toUpperCase()
})

const userName = computed(() => {
  const name = currentUser.value?.displayName || currentUser.value?.email || ''
  return name.length > 14 ? name.slice(0, 12) + '…' : name
})

async function handleLogout() {
  await logOut()
  menuOpen.value = false
}

const navItems = computed(() => [
  { label: 'HOME', path: '/' },
  { label: 'MOVIES', path: '/movies' },
  { label: 'SERIES', path: '/series' },
  { label: 'ANIMATION', path: '/animation' },
  ...(isAdmin.value ? [{ label: 'ADMIN', path: '/admin' }] : []),
])

function handleSubscribeClick() {
  if (!isLoggedIn.value) {
    loginOpen.value = true
  } else {
    subscribeOpen.value = true
  }
}

function doSearch() {
  if (searchQuery.value.trim()) {
    router.push({ path: '/', query: { q: searchQuery.value.trim() } })
  }
}
</script>

<style scoped>
/* ── Header bar ─────────────────────────────────────────────── */
.header-bar {
  width: 100%;
  max-width: 100%;
  overflow: hidden;
  background: var(--bg-header);
  backdrop-filter: blur(24px);
  -webkit-backdrop-filter: blur(24px);
  border-bottom: 1px solid var(--border);
  transition: background 0.25s ease;
}
.header-inner {
  display: flex; align-items: center; justify-content: space-between;
  gap: 4px; width: 100%; max-width: 100%; padding: 0 8px; height: 48px;
  box-sizing: border-box; overflow: hidden;
}
@media (min-width: 360px) { .header-inner { gap: 6px; padding: 0 10px; height: 50px; } }
@media (min-width: 480px) { .header-inner { gap: 10px; padding: 0 12px; height: 52px; } }

/* ── Brand ──────────────────────────────────────────────────── */
.brand-link { display: flex; align-items: center; gap: 7px; text-decoration: none; flex-shrink: 0; }
.brand-logo { height: 42px; width: auto; object-fit: contain; display: block; flex-shrink: 0; }
@media (min-width: 480px) { .brand-logo { height: 48px; } }
.brand-text { display: flex; align-items: baseline; gap: 1px; }
.brand-name { font-size: 0.82rem; font-weight: 800; letter-spacing: 0.05em; color: #fff; white-space: nowrap; }
.brand-dot { font-size: 0.62rem; font-weight: 700; color: #ff4db8; }

/* ── Desktop nav ────────────────────────────────────────────── */
.nav-item { padding: 4px 11px; border-radius: 7px; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.1em; color: rgba(255,255,255,0.48); text-decoration: none; transition: color 0.15s, background 0.15s; }
.nav-item:hover { color: rgba(255,255,255,0.9); background: rgba(255,255,255,0.06); }
.nav-item--active { color: #fff; background: rgba(255,77,184,0.1); border: 1px solid rgba(255,77,184,0.18); }
.nav-item--admin { color: #ffa600; }
.nav-item--admin:hover { color: #ffbe42; background: rgba(255,166,0,0.08); }
.nav-item--admin.nav-item--active { color: #ffa600; background: rgba(255,166,0,0.1); border-color: rgba(255,166,0,0.25); }

/* ── Search bar ─────────────────────────────────────────────── */
.header-search { display: none; }
@media (min-width: 640px) { .header-search { flex: 1; min-width: 0; max-width: 440px; display: flex; align-items: center; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); border-radius: 9999px; overflow: hidden; height: 32px; transition: border-color 0.2s, box-shadow 0.2s; } }
@media (min-width: 640px) { .header-search:focus-within { border-color: rgba(255,77,184,0.35); box-shadow: 0 0 0 3px rgba(255,77,184,0.08); } }
.hs-icon { width: 11px; height: 11px; flex-shrink: 0; margin-left: 7px; color: rgba(255,255,255,0.35); }
@media (min-width: 360px) { .hs-icon { width: 13px; height: 13px; margin-left: 10px; } }
.hs-input { flex: 1; background: transparent; border: none; outline: none; color: #fff; font-size: 0.7rem; padding: 0 4px; min-width: 0; }
@media (min-width: 360px) { .hs-input { font-size: 0.75rem; padding: 0 6px; } }
.hs-input::placeholder { color: rgba(255,255,255,0.3); font-size: 0.68rem; }
@media (min-width: 360px) { .hs-input::placeholder { font-size: 0.72rem; } }
.hs-btn { flex-shrink: 0; margin: 2px; padding: 0 8px; height: 22px; border-radius: 9999px; background: linear-gradient(135deg, #ff4db8, #ff8c00, #ffd700); color: #1a0010; font-size: 0.55rem; font-weight: 800; letter-spacing: 0.1em; border: none; cursor: pointer; transition: filter 0.2s; }
@media (min-width: 360px) { .hs-btn { margin: 3px; padding: 0 10px; height: 24px; font-size: 0.6rem; } }
@media (min-width: 480px) { .hs-btn { padding: 0 12px; font-size: 0.62rem; } }
.hs-btn:hover { filter: brightness(1.06); }

/* ── Right actions container ────────────────────────────────── */
.right-actions {
  display: flex; align-items: center; gap: 3px; flex-shrink: 0;
}
@media (min-width: 400px) { .right-actions { gap: 4px; } }
@media (min-width: 640px) { .right-actions { gap: 8px; } }

/* ── Install App button ─────────────────────────────────────── */
.btn-install {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 4px 7px; border-radius: 9999px;
  border: 1px solid rgba(255,77,184,0.35);
  background: rgba(255,77,184,0.1);
  color: #ff4db8; font-size: 0.6rem; font-weight: 700;
  letter-spacing: 0.08em; cursor: pointer;
  transition: background 0.2s, border-color 0.2s;
  white-space: nowrap; flex-shrink: 0;
}
.btn-install:hover { background: rgba(255,77,184,0.18); border-color: rgba(255,77,184,0.55); }
.install-label { display: none; }
@media (min-width: 640px) { .install-label { display: inline; } }

/* ── Theme toggle ────────────────────────────────────────────── */
.btn-theme {
  display: inline-flex; align-items: center; justify-content: center;
  width: 26px; height: 26px; border-radius: 50%; flex-shrink: 0;
  border: 1px solid var(--border); background: var(--input-bg);
  color: var(--text-dim); cursor: pointer;
  transition: background 0.2s, color 0.2s, border-color 0.2s;
}
@media (min-width: 480px) { .btn-theme { width: 30px; height: 30px; } }
.btn-theme:hover { background: var(--bg-card-hover); color: var(--text); }

/* ── Subscribe button ───────────────────────────────────────── */
.btn-subscribe {
  display: inline-flex; align-items: center; gap: 3px;
  padding: 4px 6px; border-radius: 9999px;
  border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05);
  color: rgba(255,255,255,0.68); font-size: 0.58rem; font-weight: 700;
  letter-spacing: 0.06em; cursor: pointer; transition: background 0.2s, color 0.2s;
  white-space: nowrap; flex-shrink: 0;
}
@media (min-width: 480px) { .btn-subscribe { padding: 4px 10px; gap: 4px; font-size: 0.63rem; } }
@media (min-width: 640px) { .btn-subscribe { padding: 5px 12px; font-size: 0.65rem; } }
.btn-subscribe:hover { background: rgba(255,255,255,0.09); color: #fff; }
/* Label hidden on mobile, shown on tablet+ */
.sub-label { display: none; }
@media (min-width: 480px) { .sub-label { display: inline; } }

/* ── Divider ─────────────────────────────────────────────────── */
.right-actions .h-4 { display: none; }
@media (min-width: 480px) { .right-actions .h-4 { display: block; } }

/* ── User menu ──────────────────────────────────────────────── */
.user-menu { display: flex; align-items: center; gap: 3px; flex-shrink: 0; }
@media (min-width: 400px) { .user-menu { gap: 4px; } }
/* Avatar wrap — icon-only pill on mobile, text pill on sm+ */
.user-avatar-wrap {
  display: flex; align-items: center; gap: 0;
  padding: 2px; border-radius: 50%;
  border: 1px solid rgba(255,77,184,0.25); background: rgba(255,77,184,0.07); flex-shrink: 0;
}
@media (min-width: 480px) { .user-avatar-wrap { gap: 5px; padding: 2px 7px 2px 2px; border-radius: 9999px; } }
.user-avatar {
  width: 22px; height: 22px; border-radius: 50%;
  background: linear-gradient(135deg, #ff4db8, #ffd700);
  display: flex; align-items: center; justify-content: center;
  font-size: 0.62rem; font-weight: 800; color: #1a0010; flex-shrink: 0;
}
.user-name-short { display: none; font-size: 0.65rem; font-weight: 600; color: rgba(255,255,255,0.8); max-width: 60px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
@media (min-width: 640px) { .user-name-short { display: inline; } }

/* ── Logout button ──────────────────────────────────────────── */
.btn-logout {
  display: inline-flex; align-items: center; justify-content: center; gap: 3px;
  padding: 4px 6px; border-radius: 9999px; flex-shrink: 0;
  border: 1px solid rgba(248,113,113,0.35); background: rgba(248,113,113,0.1);
  color: #f87171; font-size: 0.58rem; font-weight: 700;
  letter-spacing: 0.06em; cursor: pointer;
  transition: background 0.2s, border-color 0.2s;
  white-space: nowrap;
}
@media (min-width: 480px) { .btn-logout { padding: 4px 9px; font-size: 0.62rem; } }
.btn-logout:hover { background: rgba(248,113,113,0.2); border-color: rgba(248,113,113,0.55); }
/* Label: hidden on mobile, shown on tablet+ */
.logout-label { display: none; }
@media (min-width: 640px) { .logout-label { display: inline; } }

/* ── Login button ───────────────────────────────────────────── */
.btn-login {
  display: inline-flex; align-items: center; gap: 3px;
  padding: 4px 7px; border-radius: 9999px;
  border: 1px solid rgba(255,255,255,0.1); background: transparent;
  color: rgba(255,255,255,0.65); font-size: 0.6rem; font-weight: 700;
  letter-spacing: 0.08em; cursor: pointer; transition: background 0.2s, color 0.2s;
  white-space: nowrap; flex-shrink: 0;
}
@media (min-width: 480px) { .btn-login { padding: 5px 10px; font-size: 0.65rem; gap: 4px; } }
.btn-login:hover { background: rgba(255,255,255,0.07); color: #fff; }
.login-label { display: none; }
@media (min-width: 360px) { .login-label { display: inline; } }

/* ── Mobile bottom navigation bar ──────────────────────────── */
@media (min-width: 1024px) {
  .mobile-bottom-nav { display: none !important; }
}

.mobile-bottom-nav {
  position: fixed;
  bottom: 0; left: 0; right: 0;
  z-index: 100;
  display: flex;
  align-items: stretch;
  height: 60px;
  background: var(--bg-nav);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-top: 1px solid var(--border);
  padding-bottom: env(safe-area-inset-bottom);
  transition: background 0.25s ease;
}
.mob-nav-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  text-decoration: none;
  color: rgba(255,255,255,0.38);
  transition: color 0.15s;
  padding: 6px 2px;
  min-width: 0;
}
.mob-nav-item:hover { color: rgba(255,255,255,0.7); }
.mob-nav-item--active { color: #ff4db8; }
.mob-nav-item--admin { color: rgba(255,166,0,0.6); }
.mob-nav-item--admin.mob-nav-item--active { color: #ffa600; }
.mob-nav-icon { width: 20px; height: 20px; flex-shrink: 0; }
.mob-nav-label { font-size: 0.52rem; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
</style>
