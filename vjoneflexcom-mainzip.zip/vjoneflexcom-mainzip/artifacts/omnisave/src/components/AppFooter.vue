<template>
  <footer class="footer-root">
    <div class="care-banner">
      <div class="care-inner">

        <!-- Header row: icon + label -->
        <div class="care-left">
          <div class="care-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.07 2.18 2 2 0 012.03 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92z"/>
            </svg>
          </div>
          <div>
            <p class="care-label">CUSTOMER CARE &amp; HELP</p>
            <p class="care-desc">Available Mon–Sat · 8am – 8pm EAT</p>
          </div>
        </div>

        <!-- Phone numbers -->
        <div class="care-phones">
          <a href="tel:+211927208020" class="care-phone">
            <img class="care-flag" src="https://flagcdn.com/ss.svg" alt="South Sudan" />
            <span class="care-num">+211 927 208 020</span>
          </a>
          <div class="care-divider"></div>
          <a href="tel:+256782202045" class="care-phone">
            <img class="care-flag" src="https://flagcdn.com/ug.svg" alt="Uganda" />
            <span class="care-num">+256 782 202 045</span>
          </a>
        </div>

      </div>
    </div>
  </footer>
</template>

<script setup lang="ts">
</script>

<style scoped>
.footer-root {
  width: 100%;
  border-top: 1px solid rgba(255,255,255,0.06);
}
.care-banner {
  width: 100%;
  background: linear-gradient(90deg, rgba(255,77,184,0.07) 0%, rgba(255,215,0,0.05) 100%);
  border-bottom: 1px solid rgba(255,77,184,0.12);
}
.care-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 20px 16px;
  flex-wrap: wrap;
}
.care-left {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}
.care-icon {
  width: 40px; height: 40px; border-radius: 10px; flex-shrink: 0;
  background: rgba(255,77,184,0.12);
  border: 1px solid rgba(255,77,184,0.2);
  display: flex; align-items: center; justify-content: center;
  color: #ff4db8;
}
.care-label {
  font-size: 0.62rem; font-weight: 800; letter-spacing: 0.14em;
  color: rgba(255,77,184,0.8); text-transform: uppercase; margin-bottom: 2px;
}
.care-desc { font-size: 0.7rem; color: rgba(255,255,255,0.45); }

/* Phone block */
.care-phones {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 0;
  min-width: 0;
}
.care-phone {
  display: flex;
  align-items: center;
  gap: 8px;
  text-decoration: none;
  padding: 8px 0;
  transition: filter 0.2s;
  white-space: nowrap;
}
.care-phone:hover { filter: brightness(1.15); }
.care-flag { width: 28px; height: 19px; object-fit: cover; border-radius: 3px; flex-shrink: 0; box-shadow: 0 1px 4px rgba(0,0,0,0.35); }
.care-num {
  font-size: clamp(0.9rem, 2.8vw, 1.35rem);
  font-weight: 900;
  letter-spacing: 0.04em;
  background: linear-gradient(135deg, #ff4db8, #ff8c00, #ffd700);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.care-divider {
  width: 100%;
  height: 1px;
  background: rgba(255,77,184,0.15);
  margin: 2px 0;
}

/* Mobile: stack vertically, full width */
@media (max-width: 600px) {
  .care-inner {
    flex-direction: column;
    align-items: flex-start;
    gap: 14px;
    padding: 16px 14px;
  }
  .care-phones {
    align-items: flex-start;
    width: 100%;
    border-top: 1px solid rgba(255,77,184,0.12);
    padding-top: 12px;
  }
  .care-phone { padding: 10px 0; }
  .care-num { font-size: 1.05rem; }
}

@media (max-width: 1023px) {
  .footer-root {
    padding-bottom: calc(60px + env(safe-area-inset-bottom));
  }
}
</style>
