<template>
  <div class="tab-page">
    <div class="tab-header">
      <div>
        <h1 class="tab-title">User Activities</h1>
        <p class="tab-sub">{{ filtered.length }} event{{ filtered.length !== 1 ? 's' : '' }} · live feed</p>
      </div>
      <button class="clear-btn" @click="confirmClear" title="Clear all logs">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
        Clear Logs
      </button>
    </div>

    <!-- Filters -->
    <div class="act-filters">
      <input v-model="search" placeholder="Search by user, email or title…" class="search-input" />
      <select v-model="actionFilter" class="type-sel">
        <option value="">All Actions</option>
        <option value="content_opened">Content Opened</option>
        <option value="stream_started">Stream / Download</option>
        <option value="episode_selected">Episode Selected</option>
      </select>
      <select v-model="typeFilter" class="type-sel">
        <option value="">All Types</option>
        <option value="MOVIES">Movies</option>
        <option value="TV SERIES">TV Series</option>
        <option value="ANIMATION">Animation</option>
      </select>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="loading-row">
      <div class="spinner"></div>
      <span>Loading activities…</span>
    </div>

    <!-- Main table -->
    <div v-else class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>User</th>
            <th>Email</th>
            <th>UID</th>
            <th>Action</th>
            <th>Title</th>
            <th>Type</th>
            <th>Category</th>
            <th>Ep #</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="a in paginated" :key="a.docId">
            <td class="td-date">{{ a.timeStr }}</td>
            <td>
              <div class="user-cell">
                <div class="user-avatar">{{ (a.userName || '?')[0].toUpperCase() }}</div>
                <span class="user-name">{{ a.userName }}</span>
              </div>
            </td>
            <td class="td-email">{{ a.userEmail }}</td>
            <td class="td-uid" :title="a.uid">{{ a.uid.slice(0, 8) }}…</td>
            <td><span class="action-badge" :class="actionCls(a.action)">{{ actionLabel(a.action) }}</span></td>
            <td class="td-title">{{ a.contentTitle || '—' }}</td>
            <td><span class="type-badge" :class="typeCls(a.contentType)">{{ typeLabel(a.contentType) }}</span></td>
            <td class="td-cat">{{ a.contentCategory || '—' }}</td>
            <td class="td-ep">{{ a.episodeNumber != null ? a.episodeNumber : '—' }}</td>
          </tr>
          <tr v-if="filtered.length === 0">
            <td colspan="9" class="empty-row">No activity recorded yet. Activity appears here as users interact with the site.</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div v-if="totalPages > 1" class="pagination">
      <button class="page-btn" :disabled="page === 1" @click="page--">‹ Prev</button>
      <span class="page-info">{{ page }} / {{ totalPages }}</span>
      <button class="page-btn" :disabled="page === totalPages" @click="page++">Next ›</button>
    </div>

    <!-- Per-user summary -->
    <div class="breakdown-section">
      <h2 class="breakdown-title">Top Active Users</h2>
      <div class="user-cards">
        <div v-for="u in topUsers" :key="u.uid" class="user-card">
          <div class="uc-avatar">{{ (u.userName || '?')[0].toUpperCase() }}</div>
          <div class="uc-info">
            <p class="uc-name">{{ u.userName }}</p>
            <p class="uc-email">{{ u.userEmail }}</p>
            <p class="uc-uid">{{ u.uid }}</p>
          </div>
          <div class="uc-stats">
            <div class="uc-count">{{ u.total }}</div>
            <div class="uc-label">actions</div>
            <div class="uc-breakdown">
              <span v-if="u.content_opened" class="mini-badge badge-open">{{ u.content_opened }} opened</span>
              <span v-if="u.stream_started" class="mini-badge badge-stream">{{ u.stream_started }} streamed</span>
              <span v-if="u.episode_selected" class="mini-badge badge-ep">{{ u.episode_selected }} ep</span>
            </div>
          </div>
        </div>
        <div v-if="topUsers.length === 0 && !loading" class="empty-row" style="text-align:center;padding:20px">No data yet</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { collection, onSnapshot, orderBy, query, limit, deleteDoc, doc } from 'firebase/firestore'
import { db } from '../../lib/firebase'

interface ActivityLog {
  docId: string
  uid: string
  userName: string
  userEmail: string
  action: string
  contentId: string
  contentTitle: string
  contentType: string
  contentCategory: string
  episodeNumber: number | null
  timestamp: any
  timeStr: string
}

const logs = ref<ActivityLog[]>([])
const loading = ref(true)
const search = ref('')
const actionFilter = ref('')
const typeFilter = ref('')
const page = ref(1)
const PAGE_SIZE = 50

let unsub: (() => void) | null = null

onMounted(() => {
  const q = query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'), limit(500))
  unsub = onSnapshot(q, (snap) => {
    logs.value = snap.docs.map(d => {
      const data = d.data()
      const ts = data.timestamp?.toDate?.() as Date | undefined
      return {
        docId: d.id,
        uid:          data.uid          ?? '',
        userName:     data.userName     ?? '',
        userEmail:    data.userEmail    ?? '',
        action:       data.action       ?? '',
        contentId:    data.contentId    ?? '',
        contentTitle: data.contentTitle ?? '',
        contentType:  data.contentType  ?? '',
        contentCategory: data.contentCategory ?? '',
        episodeNumber: data.episodeNumber ?? null,
        timestamp: ts,
        timeStr: ts ? formatTime(ts) : '—',
      }
    })
    loading.value = false
  }, () => { loading.value = false })
})

onUnmounted(() => { unsub?.() })

function formatTime(d: Date): string {
  return d.toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

const filtered = computed(() => {
  let list = logs.value
  const q = search.value.toLowerCase().trim()
  if (q) list = list.filter(a =>
    a.userName.toLowerCase().includes(q) ||
    a.userEmail.toLowerCase().includes(q) ||
    a.uid.toLowerCase().includes(q) ||
    a.contentTitle.toLowerCase().includes(q)
  )
  if (actionFilter.value) list = list.filter(a => a.action === actionFilter.value)
  if (typeFilter.value) list = list.filter(a => a.contentType === typeFilter.value)
  return list
})

const totalPages = computed(() => Math.max(1, Math.ceil(filtered.value.length / PAGE_SIZE)))
const paginated = computed(() => {
  const start = (page.value - 1) * PAGE_SIZE
  return filtered.value.slice(start, start + PAGE_SIZE)
})

// Reset page when filters change
watch([search, actionFilter, typeFilter], () => { page.value = 1 })

// Top users summary
const topUsers = computed(() => {
  const map = new Map<string, { uid: string; userName: string; userEmail: string; total: number; content_opened: number; stream_started: number; episode_selected: number }>()
  for (const a of logs.value) {
    if (!map.has(a.uid)) map.set(a.uid, { uid: a.uid, userName: a.userName, userEmail: a.userEmail, total: 0, content_opened: 0, stream_started: 0, episode_selected: 0 })
    const u = map.get(a.uid)!
    u.total++
    if (a.action === 'content_opened')   u.content_opened++
    if (a.action === 'stream_started')   u.stream_started++
    if (a.action === 'episode_selected') u.episode_selected++
  }
  return Array.from(map.values()).sort((a, b) => b.total - a.total).slice(0, 10)
})

async function confirmClear() {
  for (const log of logs.value) {
    await deleteDoc(doc(db, 'activityLogs', log.docId))
  }
}

function actionLabel(a: string) {
  if (a === 'content_opened')   return 'Opened'
  if (a === 'stream_started')   return 'Streamed'
  if (a === 'episode_selected') return 'Episode'
  return a
}
function actionCls(a: string) {
  if (a === 'content_opened')   return 'badge-open'
  if (a === 'stream_started')   return 'badge-stream'
  if (a === 'episode_selected') return 'badge-ep'
  return ''
}
function typeLabel(t: string) {
  if (t === 'MOVIES')    return 'Movie'
  if (t === 'TV SERIES') return 'Series'
  if (t === 'ANIMATION') return 'Anime'
  return t || '—'
}
function typeCls(t: string) {
  if (t === 'MOVIES')    return 'type-movie'
  if (t === 'TV SERIES') return 'type-series'
  if (t === 'ANIMATION') return 'type-anim'
  return ''
}
</script>

<style scoped>
.tab-page { padding: 20px 14px 32px; }
@media (min-width: 640px)  { .tab-page { padding: 24px 20px 36px; } }
@media (min-width: 1024px) { .tab-page { padding: 28px 28px 40px; } }

.tab-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; margin-bottom: 18px; flex-wrap: wrap; }
.tab-title { font-size: 1.3rem; font-weight: 800; color: #fff; margin-bottom: 3px; }
@media (min-width: 640px) { .tab-title { font-size: 1.5rem; } }
.tab-sub { font-size: 0.78rem; color: rgba(255,255,255,0.4); }

.clear-btn { display: flex; align-items: center; gap: 6px; padding: 7px 14px; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.25); border-radius: 8px; color: #f87171; font-size: 0.75rem; font-weight: 700; cursor: pointer; transition: background 0.15s; }
.clear-btn:hover { background: rgba(239,68,68,0.16); }

.act-filters { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }
.search-input { flex: 1; min-width: 200px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 8px 13px; color: #fff; font-size: 0.83rem; outline: none; }
.search-input:focus { border-color: rgba(255,77,184,0.4); }
.search-input::placeholder { color: rgba(255,255,255,0.25); }
.type-sel { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 8px 12px; color: rgba(255,255,255,0.7); font-size: 0.8rem; outline: none; }
.type-sel option { background: #0d1a10; }

.loading-row { display: flex; align-items: center; gap: 10px; padding: 40px; color: rgba(255,255,255,0.4); font-size: 0.85rem; }
.spinner { width: 22px; height: 22px; border: 2px solid rgba(255,77,184,0.15); border-top-color: #ff4db8; border-radius: 50%; animation: spin 0.8s linear infinite; flex-shrink: 0; }
@keyframes spin { to { transform: rotate(360deg); } }

.table-wrap { overflow-x: auto; border-radius: 12px; border: 1px solid rgba(255,255,255,0.07); margin-bottom: 16px; }
.data-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; min-width: 820px; }
.data-table thead th { background: rgba(255,255,255,0.04); padding: 10px 12px; text-align: left; font-size: 0.67rem; font-weight: 700; color: rgba(255,255,255,0.4); letter-spacing: 0.08em; text-transform: uppercase; white-space: nowrap; }
.data-table tbody tr { border-top: 1px solid rgba(255,255,255,0.05); transition: background 0.12s; }
.data-table tbody tr:hover { background: rgba(255,255,255,0.025); }
.data-table td { padding: 9px 12px; color: rgba(255,255,255,0.8); vertical-align: middle; }

.td-date  { color: rgba(255,255,255,0.4); font-size: 0.72rem; white-space: nowrap; }
.td-email { color: rgba(255,255,255,0.5); font-size: 0.75rem; }
.td-uid   { color: rgba(255,255,255,0.3); font-size: 0.7rem; font-family: monospace; cursor: help; }
.td-title { font-weight: 600; color: #fff; max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.td-cat   { color: rgba(255,255,255,0.45); font-size: 0.76rem; }
.td-ep    { color: rgba(255,255,255,0.55); text-align: center; }
.empty-row { text-align: center; color: rgba(255,255,255,0.25); padding: 36px 16px; font-size: 0.82rem; }

.user-cell   { display: flex; align-items: center; gap: 8px; }
.user-avatar { width: 26px; height: 26px; border-radius: 50%; background: linear-gradient(135deg, #ff4db8, #ffd700); display: flex; align-items: center; justify-content: center; font-size: 0.68rem; font-weight: 800; color: #1a0010; flex-shrink: 0; }
.user-name   { font-weight: 600; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 120px; }

/* Action badges */
.action-badge { font-size: 0.62rem; font-weight: 800; padding: 2px 7px; border-radius: 4px; letter-spacing: 0.05em; white-space: nowrap; }
.badge-open   { background: rgba(59,130,246,0.12); color: #60a5fa; border: 1px solid rgba(59,130,246,0.22); }
.badge-stream { background: rgba(255,77,184,0.1);   color: #ff4db8; border: 1px solid rgba(255,77,184,0.2); }
.badge-ep     { background: rgba(251,191,36,0.1);  color: #fbbf24; border: 1px solid rgba(251,191,36,0.2); }

/* Type badges */
.type-badge  { font-size: 0.62rem; font-weight: 800; padding: 2px 7px; border-radius: 4px; white-space: nowrap; }
.type-movie  { background: rgba(255,77,184,0.08);  color: #ff4db8; border: 1px solid rgba(255,77,184,0.18); }
.type-series { background: rgba(255,166,0,0.08);  color: #ffa600; border: 1px solid rgba(255,166,0,0.18); }
.type-anim   { background: rgba(208,138,255,0.08);color: #d08aff; border: 1px solid rgba(208,138,255,0.18); }

/* Pagination */
.pagination { display: flex; align-items: center; gap: 12px; margin-bottom: 28px; justify-content: center; }
.page-btn { padding: 6px 16px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: rgba(255,255,255,0.6); font-size: 0.8rem; font-weight: 600; cursor: pointer; transition: background 0.15s; }
.page-btn:hover:not(:disabled) { background: rgba(255,255,255,0.08); color: #fff; }
.page-btn:disabled { opacity: 0.3; cursor: not-allowed; }
.page-info { font-size: 0.8rem; color: rgba(255,255,255,0.4); }

/* Per-user breakdown */
.breakdown-section { margin-top: 8px; }
.breakdown-title { font-size: 0.95rem; font-weight: 800; color: #fff; margin-bottom: 12px; }
.user-cards { display: flex; flex-direction: column; gap: 8px; }
.user-card { display: flex; align-items: center; gap: 14px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.07); border-radius: 12px; padding: 12px 16px; flex-wrap: wrap; }
.uc-avatar { width: 38px; height: 38px; border-radius: 50%; background: linear-gradient(135deg, #ff4db8, #ffd700); display: flex; align-items: center; justify-content: center; font-size: 1rem; font-weight: 800; color: #1a0010; flex-shrink: 0; }
.uc-info { flex: 1; min-width: 0; }
.uc-name  { font-weight: 700; color: #fff; font-size: 0.88rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.uc-email { font-size: 0.73rem; color: rgba(255,255,255,0.45); margin-top: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.uc-uid   { font-size: 0.67rem; color: rgba(255,255,255,0.25); font-family: monospace; margin-top: 1px; }
.uc-stats { display: flex; flex-direction: column; align-items: flex-end; gap: 3px; }
.uc-count { font-size: 1.6rem; font-weight: 900; color: #ff4db8; line-height: 1; }
.uc-label { font-size: 0.6rem; color: rgba(255,255,255,0.3); font-weight: 600; text-transform: uppercase; letter-spacing: 0.08em; }
.uc-breakdown { display: flex; gap: 4px; flex-wrap: wrap; justify-content: flex-end; margin-top: 2px; }
.mini-badge { font-size: 0.58rem; font-weight: 700; padding: 1px 6px; border-radius: 4px; }
</style>
