<template>
  <div class="tab-page">
    <div class="tab-header">
      <div class="header-left">
        <h1 class="tab-title">Subscription Plans</h1>
        <p class="tab-sub">Plans defined here appear as buttons when activating users</p>
      </div>
      <button class="add-btn" @click="openAdd">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Add Plan
      </button>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="state-box">
      <div class="spin-ring"></div>
      <p class="state-text">Loading plans…</p>
    </div>

    <!-- Empty -->
    <div v-else-if="plans.length === 0" class="state-box">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="1.5"><rect x="1" y="4" width="22" height="16" rx="2"/><path d="M1 10h22"/></svg>
      <p class="state-text">No subscription plans yet.</p>
      <p class="state-sub">Click "Add Plan" to create your first plan.</p>
    </div>

    <!-- Plans grid -->
    <div v-else class="plans-grid">
      <div v-for="plan in plans" :key="plan.key" class="plan-card">
        <div class="plan-badge">{{ formatDuration(plan.durationDays) }}</div>
        <div class="plan-name">{{ plan.name }}</div>
        <div class="plan-price">
          <span class="price-currency">UGX</span>
          <span class="price-amount">{{ plan.price.toLocaleString() }}</span>
        </div>
        <div class="plan-meta">{{ plan.durationDays }} day{{ plan.durationDays !== 1 ? 's' : '' }} access</div>
        <div class="plan-actions">
          <button class="btn-edit" @click="openEdit(plan)">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            Edit
          </button>
          <button class="btn-delete" @click="confirmDelete(plan)" :disabled="deleting === plan.key">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
            Delete
          </button>
        </div>
      </div>
    </div>

    <!-- Add / Edit Modal -->
    <div v-if="showModal" class="modal-backdrop" @click.self="closeModal">
      <div class="modal">
        <div class="modal-header">
          <h2 class="modal-title">{{ editing ? 'Edit Plan' : 'New Subscription Plan' }}</h2>
          <button class="modal-close" @click="closeModal">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        <div class="modal-body">
          <div class="field">
            <label class="field-label">Plan Name</label>
            <input v-model="form.name" class="field-input" placeholder="e.g. 1 Week Pass" maxlength="60" />
            <span class="field-hint">Shown to users and in activation buttons</span>
          </div>
          <div class="field-row">
            <div class="field">
              <label class="field-label">Price (UGX)</label>
              <input v-model.number="form.price" type="number" min="0" class="field-input" placeholder="e.g. 5000" />
            </div>
            <div class="field">
              <label class="field-label">Duration (days)</label>
              <input v-model.number="form.durationDays" type="number" min="1" class="field-input" placeholder="e.g. 7" />
            </div>
          </div>

          <div v-if="form.durationDays > 0 || form.price > 0" class="preview-box">
            <span class="preview-label">Preview</span>
            <span class="preview-pill">{{ form.name || 'Plan Name' }}</span>
            <span class="preview-detail">UGX {{ (form.price || 0).toLocaleString() }} · {{ form.durationDays || 0 }} day{{ form.durationDays !== 1 ? 's' : '' }}</span>
          </div>

          <p v-if="formError" class="form-error">{{ formError }}</p>
        </div>

        <div class="modal-footer">
          <button class="btn-cancel" @click="closeModal">Cancel</button>
          <button class="btn-save" @click="savePlan" :disabled="saving">
            <span v-if="saving" class="btn-spin"></span>
            {{ saving ? 'Saving…' : (editing ? 'Save Changes' : 'Add Plan') }}
          </button>
        </div>
      </div>
    </div>

    <!-- Delete confirmation -->
    <div v-if="deleteTarget" class="modal-backdrop" @click.self="deleteTarget = null">
      <div class="modal modal-sm">
        <div class="modal-header">
          <h2 class="modal-title">Delete Plan</h2>
        </div>
        <div class="modal-body">
          <p class="confirm-text">
            Are you sure you want to delete <strong>{{ deleteTarget.name }}</strong>?
            This won't affect existing user subscriptions.
          </p>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="deleteTarget = null">Cancel</button>
          <button class="btn-delete-confirm" @click="doDelete" :disabled="!!deleting">
            <span v-if="deleting" class="btn-spin"></span>
            Delete
          </button>
        </div>
      </div>
    </div>

    <div v-if="toast" class="toast">{{ toast }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import {
  dbSubscriptionPlans,
  addSubscriptionPlan,
  updateSubscriptionPlan,
  removeSubscriptionPlan,
} from '../../store/db'
import type { SubscriptionPlan } from '../../store/db'

const loading = computed(() => false) // plans stream from reactive ref
const plans = dbSubscriptionPlans

const showModal = ref(false)
const editing = ref<SubscriptionPlan | null>(null)
const form = ref({ name: '', price: 0, durationDays: 1 })
const formError = ref('')
const saving = ref(false)
const deleting = ref<string | null>(null)
const deleteTarget = ref<SubscriptionPlan | null>(null)
const toast = ref('')

function showToast(msg: string) {
  toast.value = msg
  setTimeout(() => { toast.value = '' }, 2800)
}

function formatDuration(days: number): string {
  if (days === 1) return '1 DAY'
  if (days < 7) return `${days} DAYS`
  if (days === 7) return '1 WEEK'
  if (days === 14) return '2 WEEKS'
  if (days >= 30 && days < 60) return '1 MONTH'
  if (days >= 60 && days < 90) return '2 MONTHS'
  if (days >= 365) return `${Math.round(days / 365)} YEAR`
  return `${days} DAYS`
}

function openAdd() {
  editing.value = null
  form.value = { name: '', price: 0, durationDays: 1 }
  formError.value = ''
  showModal.value = true
}

function openEdit(plan: SubscriptionPlan) {
  editing.value = plan
  form.value = { name: plan.name, price: plan.price, durationDays: plan.durationDays }
  formError.value = ''
  showModal.value = true
}

function closeModal() {
  showModal.value = false
  editing.value = null
  formError.value = ''
}

async function savePlan() {
  formError.value = ''
  if (!form.value.name.trim()) { formError.value = 'Plan name is required.'; return }
  if (form.value.price < 0) { formError.value = 'Price must be 0 or more.'; return }
  if (!form.value.durationDays || form.value.durationDays < 1) { formError.value = 'Duration must be at least 1 day.'; return }

  saving.value = true
  try {
    const payload = {
      name: form.value.name.trim(),
      price: form.value.price,
      durationDays: form.value.durationDays,
    }
    if (editing.value) {
      await updateSubscriptionPlan(editing.value.key, payload)
      showToast('✓ Plan updated')
    } else {
      await addSubscriptionPlan(payload)
      showToast('✓ Plan added')
    }
    closeModal()
  } catch (e: any) {
    formError.value = e?.message || 'Failed to save plan.'
  }
  saving.value = false
}

function confirmDelete(plan: SubscriptionPlan) {
  deleteTarget.value = plan
}

async function doDelete() {
  if (!deleteTarget.value) return
  deleting.value = deleteTarget.value.key
  try {
    await removeSubscriptionPlan(deleteTarget.value.key)
    showToast('Plan deleted')
    deleteTarget.value = null
  } catch (e: any) {
    showToast(`Error: ${e?.message || 'Failed to delete'}`)
  }
  deleting.value = null
}
</script>

<style scoped>
@keyframes spin { to { transform: rotate(360deg); } }

.tab-page { padding: 28px 24px; position: relative; min-height: 300px; }
@media (max-width: 640px) { .tab-page { padding: 14px 10px; } }

.tab-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }
.header-left { display: flex; flex-direction: column; gap: 4px; }
.tab-title { font-size: 1.5rem; font-weight: 900; color: #fff; margin: 0; }
@media (max-width: 640px) { .tab-title { font-size: 1.2rem; } }
.tab-sub { font-size: 0.75rem; color: rgba(255,255,255,0.35); margin: 0; }

.add-btn { display: inline-flex; align-items: center; gap: 7px; padding: 9px 18px; background: #ff4db8; border: none; border-radius: 10px; color: #fff; font-size: 0.82rem; font-weight: 700; cursor: pointer; white-space: nowrap; transition: filter 0.15s, transform 0.1s; }
.add-btn:hover { filter: brightness(1.1); transform: translateY(-1px); }

.state-box { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px; padding: 60px 16px; text-align: center; }
.spin-ring { width: 32px; height: 32px; border: 3px solid rgba(255,77,184,0.15); border-top-color: #ff4db8; border-radius: 50%; animation: spin 0.8s linear infinite; }
.state-text { font-size: 0.85rem; color: rgba(255,255,255,0.4); margin: 0; }
.state-sub { font-size: 0.75rem; color: rgba(255,255,255,0.2); margin: 0; }

.plans-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 14px; }
/* 2 columns on small phones; single column on very tiny screens */
@media (max-width: 480px) { .plans-grid { grid-template-columns: 1fr 1fr; gap: 10px; } }
@media (max-width: 340px) { .plans-grid { grid-template-columns: 1fr; } }

.plan-card { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.09); border-radius: 14px; padding: 20px 18px 16px; display: flex; flex-direction: column; gap: 6px; transition: border-color 0.2s, background 0.2s; }
@media (max-width: 480px) { .plan-card { padding: 14px 12px 12px; border-radius: 11px; } }
.plan-card:hover { border-color: rgba(255,77,184,0.25); background: rgba(255,77,184,0.03); }

.plan-badge { display: inline-flex; align-self: flex-start; padding: 3px 10px; border-radius: 9999px; background: rgba(255,77,184,0.1); border: 1px solid rgba(255,77,184,0.25); color: #ff4db8; font-size: 0.6rem; font-weight: 800; letter-spacing: 0.1em; margin-bottom: 4px; }
.plan-name { font-size: 1rem; font-weight: 800; color: #fff; line-height: 1.2; }
@media (max-width: 480px) { .plan-name { font-size: 0.88rem; } }
.plan-price { display: flex; align-items: baseline; gap: 5px; margin-top: 4px; }
.price-currency { font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,0.45); }
.price-amount { font-size: 1.6rem; font-weight: 900; color: #fff; line-height: 1; }
@media (max-width: 480px) { .price-amount { font-size: 1.25rem; } }
.plan-meta { font-size: 0.72rem; color: rgba(255,255,255,0.35); }
@media (max-width: 480px) { .plan-meta { font-size: 0.65rem; } }

.plan-actions { display: flex; gap: 8px; margin-top: 12px; }
.btn-edit { flex: 1; display: inline-flex; align-items: center; justify-content: center; gap: 5px; padding: 7px 0; border-radius: 8px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.7); font-size: 0.72rem; font-weight: 700; cursor: pointer; transition: background 0.15s; }
.btn-edit:hover { background: rgba(255,255,255,0.1); color: #fff; }
.btn-delete { flex: 1; display: inline-flex; align-items: center; justify-content: center; gap: 5px; padding: 7px 0; border-radius: 8px; background: rgba(220,38,38,0.08); border: 1px solid rgba(220,38,38,0.2); color: #f87171; font-size: 0.72rem; font-weight: 700; cursor: pointer; transition: background 0.15s; }
.btn-delete:hover { background: rgba(220,38,38,0.16); }
.btn-delete:disabled { opacity: 0.5; cursor: default; }

/* Modal */
.modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(4px); z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 16px; }
.modal { background: #0a1a0f; border: 1px solid rgba(255,255,255,0.12); border-radius: 16px; width: 100%; max-width: 460px; overflow: hidden; box-shadow: 0 24px 64px rgba(0,0,0,0.6); }
.modal-sm { max-width: 360px; }
.modal-header { display: flex; align-items: center; justify-content: space-between; padding: 20px 24px 0; }
.modal-title { font-size: 1.05rem; font-weight: 800; color: #fff; margin: 0; }
.modal-close { background: none; border: none; color: rgba(255,255,255,0.4); cursor: pointer; padding: 4px; border-radius: 6px; display: flex; align-items: center; transition: color 0.15s; }
.modal-close:hover { color: #fff; }
.modal-body { padding: 20px 24px; display: flex; flex-direction: column; gap: 18px; }
.modal-footer { display: flex; gap: 10px; justify-content: flex-end; padding: 0 24px 20px; }

.field { display: flex; flex-direction: column; gap: 6px; flex: 1; }
.field-row { display: flex; gap: 14px; }
@media (max-width: 400px) { .field-row { flex-direction: column; } }
.field-label { font-size: 0.72rem; font-weight: 700; color: rgba(255,255,255,0.5); text-transform: uppercase; letter-spacing: 0.06em; }
.field-input { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); border-radius: 9px; padding: 10px 14px; color: #fff; font-size: 0.9rem; outline: none; transition: border-color 0.2s; width: 100%; box-sizing: border-box; }
.field-input:focus { border-color: rgba(255,77,184,0.5); }
.field-input::placeholder { color: rgba(255,255,255,0.2); }
.field-hint { font-size: 0.68rem; color: rgba(255,255,255,0.25); }

.preview-box { background: rgba(255,77,184,0.05); border: 1px solid rgba(255,77,184,0.15); border-radius: 10px; padding: 12px 16px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.preview-label { font-size: 0.62rem; font-weight: 700; color: rgba(255,77,184,0.6); text-transform: uppercase; letter-spacing: 0.1em; }
.preview-pill { background: #ff4db8; color: #fff; padding: 5px 14px; border-radius: 9999px; font-size: 0.78rem; font-weight: 700; }
.preview-detail { font-size: 0.75rem; color: rgba(255,255,255,0.4); }

.form-error { font-size: 0.78rem; color: #f87171; margin: 0; }

.btn-cancel { padding: 9px 18px; border-radius: 9px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.6); font-size: 0.82rem; font-weight: 700; cursor: pointer; }
.btn-cancel:hover { background: rgba(255,255,255,0.09); }
.btn-save { display: inline-flex; align-items: center; gap: 7px; padding: 9px 22px; border-radius: 9px; background: #ff4db8; border: none; color: #fff; font-size: 0.82rem; font-weight: 700; cursor: pointer; transition: filter 0.15s; }
.btn-save:hover { filter: brightness(1.1); }
.btn-save:disabled { opacity: 0.6; cursor: default; }
.btn-delete-confirm { display: inline-flex; align-items: center; gap: 7px; padding: 9px 22px; border-radius: 9px; background: #dc2626; border: none; color: #fff; font-size: 0.82rem; font-weight: 700; cursor: pointer; }
.btn-delete-confirm:disabled { opacity: 0.6; cursor: default; }
.btn-spin { width: 13px; height: 13px; border: 2px solid rgba(255,255,255,0.3); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; }

.confirm-text { font-size: 0.88rem; color: rgba(255,255,255,0.65); line-height: 1.5; margin: 0; }
.confirm-text strong { color: #fff; }

.toast { position: fixed; bottom: 80px; left: 50%; transform: translateX(-50%); background: rgba(0,20,12,0.95); border: 1px solid rgba(255,77,184,0.3); color: #ff4db8; padding: 12px 24px; border-radius: 10px; font-size: 0.85rem; font-weight: 600; z-index: 9999; backdrop-filter: blur(12px); white-space: nowrap; box-shadow: 0 8px 32px rgba(0,0,0,0.5); }
@media (min-width: 1024px) { .toast { bottom: 28px; } }
</style>
