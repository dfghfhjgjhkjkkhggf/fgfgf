export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
  res.setHeader('Cache-Control', 'no-store')

  if (req.method === 'OPTIONS') {
    return res.status(204).end()
  }

  const path = Array.isArray(req.query.path) ? req.query.path.join('/') : (req.query.path || '')
  const normalizedPath = path.replace(/^\/+/, '').toLowerCase()
  const extra = { ...req.query }
  delete extra.path
  const qs = new URLSearchParams(extra).toString()
  const targetUrl = `https://pay.pesapal.com/v3/${path}${qs ? '?' + qs : ''}`

  const forwardHeaders = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  }
  if (req.headers['authorization']) {
    forwardHeaders['Authorization'] = req.headers['authorization']
  }

  let body =
    req.method !== 'GET' && req.method !== 'HEAD'
      ? typeof req.body === 'string' ? req.body : JSON.stringify(req.body)
      : undefined

  if (req.method === 'POST' && normalizedPath === 'api/auth/requesttoken') {
    const consumerKey = process.env.PESAPAL_CONSUMER_KEY
    const consumerSecret = process.env.PESAPAL_CONSUMER_SECRET

    if (!consumerKey || !consumerSecret) {
      return res.status(500).json({ error: 'Payment service credentials are not configured.' })
    }

    body = JSON.stringify({
      consumer_key: consumerKey,
      consumer_secret: consumerSecret,
    })
  }

  try {
    const upstream = await fetch(targetUrl, {
      method: req.method,
      headers: forwardHeaders,
      body,
    })

    const contentType = upstream.headers.get('content-type') || 'application/json'
    const text = await upstream.text()
    res.setHeader('Content-Type', contentType)
    res.status(upstream.status).send(text)
  } catch (err) {
    res.status(502).json({ error: 'Proxy error', detail: String(err) })
  }
}
