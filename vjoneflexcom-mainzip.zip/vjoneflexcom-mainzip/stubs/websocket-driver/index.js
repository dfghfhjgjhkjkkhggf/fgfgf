// Stub: websocket-driver is pulled in by @firebase/database → faye-websocket,
// but this project never uses the Realtime Database, so this is safe to stub.
module.exports = {
  http: () => null,
  server: () => null,
  client: () => null,
};
